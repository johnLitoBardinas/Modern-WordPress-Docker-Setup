<?php (dynamic_sidebar('sidebar-primary')); ?>
<?php /**PATH /var/www/html/web/app/themes/sage10/resources/views/sections/sidebar.blade.php ENDPATH**/ ?>