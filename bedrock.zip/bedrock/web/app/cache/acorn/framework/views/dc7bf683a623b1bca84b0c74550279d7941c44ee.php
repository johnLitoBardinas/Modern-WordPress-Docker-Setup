<div class="page-header">
  <h1><?php echo $title; ?></h1>
</div>
<?php /**PATH /var/www/html/web/app/themes/sage10/resources/views/partials/page-header.blade.php ENDPATH**/ ?>