<footer class="content-info">
  <?php (dynamic_sidebar('sidebar-footer')); ?>
</footer>
<?php /**PATH /var/www/html/web/app/themes/sage10/resources/views/sections/footer.blade.php ENDPATH**/ ?>