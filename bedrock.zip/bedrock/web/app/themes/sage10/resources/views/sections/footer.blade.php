<footer class="content-info">
  @php(dynamic_sidebar('sidebar-footer'))
</footer>
